---
name: test-question-writing
description: Tibbiy test savollarini (5 variantli, bitta to'g'ri javobli) faqat mavzu matnidan yozish qat'iy qoidalari. Javob va izoh matnga tayanadi, kitob nomi aytilmaydi, shablon so'zlar va takror variantlar taqiqlanadi. questions/*.json formatida savol yozishda ishlatiladi.
---

# Savol yozish qoidalari (qat'iy)

Savollar mavzuni mustahkamlash uchun yoziladi. Har bir savol, har bir variant va har bir izoh faqat `NNN.txt` mavzu matnidan olinadi.

## Asosiy qoidalar

1. **Shablon so'zlar yo'q.** Variantlarda `xolos`, `shu`, `tez`, `odatiy` so'zlari ishlatilmaydi. Bir xil variant ikki savolda takrorlanmaydi.
2. **Hamma variant mavzuga tegishli.** Noto'g'ri javoblar ham shu mavzu matnidagi tushuncha, raqam, nom yoki holatlardan olinadi. Boshqa soha yoki umumiy gaplar (masalan, bank, sport, ofis) yozilmaydi. Har bir variantning so'zlarining kamida 70% i mavzu matnida bo'lishi kerak.
2a. **Variant savolga bog'liq bo'lishi kerak.** Noto'g'ri javob ham savol mavzusidagi mazmunga tegishli bo'lsin. Savolga aloqasi yo'q gap (masalan, "dorixona xodimlarining oylik maoshi", "shifokor ish grafigi", "dori-darmonlarning narxi" kabi, matnda bor bo'lsa ham) variant sifatida yozilmaydi. Har bir variantni o'qiganda: "bu savolga javob bo'la oladimi?" degan savolga ha deb javob berilishi kerak, aks holda variant almashtiriladi.
3. **Ma'no to'liq bo'lsin.** Variant gap bo'lib tugasin; `va`, `yoki`, `bilan`, `uchun`, `kabi` bilan tugamasin, vergul yoki tire bilan yakunlanmasin.
4. **Izoh = iqtibos.** `x` maydoni faqat mavzu matnidan to'g'ridan-to'g'ri olingan jumla bo'lsin, «» belgisi ichida. Iqtibos to'g'ri javobni qo'llab-quvvatlashi kerak. Izohda iqtibosdan tashqari hech narsa yozilmaydi.
5. **Kitob va manba nomi aytilmaydi.** Savol, variant va izohda `darslik`, `kitob`, `taqdimot`, `Mirtazaev`, `Pakirdinov`, `manbada`, `deyilgan`, `ko'rsatilgan`, `qayd etilgan`, `tasdiqlanmagan` kabi so'zlar bo'lmasin («» ichidagi iqtibos bundan mustasno emas: u ham shunday bo'lmasin).
6. **Maqsad — mustahkamlash.** Savol mavzudagi asosiy tushunchani so'raydi (ta'rif, sabab, belgi, usul, me'yor), mavzudan tashqari bilim talab qilmaydi.
7. **Hech narsa o'ylab topilmaydi.** Matnda yo'q raqam, nom, doza yoki fakt yozilmaydi.
8. **Tasdiqlanmagan faktlar.** Matnda `[tasdiqlanmagan ...]` bilan belgilangan faktlar savol javobi (to'g'ri javob) bo'lmaydi.

## JSON format

Har fayl: `{ "NNN": [ {q, c, w:[4 ta], x}, ... ], "MMM": [...] }`

- `q` — savol matni, `?` bilan tugaydi.
- `c` — to'g'ri javob (matnga tayangan).
- `w` — **aynan 4 ta** noto'g'ri javob, ular ham mavzu matnidan olinadi.
- `x` — faqat iqtibos: `«mavzu matnidan aynan olingan jumla»`.

Harf (A–E) va variantlar tartibini builder qo'yadi. Izoh avtomatik: `To'g'ri javob: <c>. «...» (NNN.docx)`. Iqtibos to'g'ridan-to'g'ri yoziladi: oldiga «Mavzu matnidan iqtibos:» kabi sarlavha yoki boshqa so'z qo'shilmaydi.

## Tekshiruv (build_tests.js qat'iy rejimda bajaradi)

Xato bo'lsa fayllar yozilmaydi (exit 1). Quyidagilar tekshiriladi:

- Savollar soni ≥ 10; savol `?` bilan tugaydi; 4 ta `w` bor; variantlar takrorlanmaydi.
- Taqiqlangan so'zlar (kitob, muallif, `deyilgan`, `ko'rsatilgan` va h.k.) savol va variantlarda yo'q.
- Shablon so'zlar (`xolos`, `shu`, `tez`, `odatiy`) variantlarda yo'q.
- Har bir variantning so'zlari ≥70% mavzu matnida bor (`NNN.txt`).
- Variant tugallanmagan emas (bog'lovchi/vergul bilan tugamaydi, 2 ta so'zdan kam emas, raqamli bo'lsa mustasno).
- Izoh faqat `« »` ichidagi iqtibos; iqtibos `NNN.txt` da aynan uchraydi; iqtibos to'g'ri javob so'zlarining ≥50% ini o'z ichiga oladi.
- Bir xil variant matni ikki savolda takrorlanmaydi.
- To'g'ri javob eng uzun noto'g'ri javobdan >30% uzun bo'lsa xato; >10% bo'lsa ogohlantirish.
- Noto'g'ri javoblarda `Faqat/Hech/Umuman/Barcha` bilan boshlanuvchi ko'pi bilan bitta; uchta va undan ko'p variant bir xil so'z bilan boshlanmasin.

## Tez-tez uchraydigan xatolar

- Izohga "Darslikda ... deyilgan" yozish — taqiqlangan. Faqat iqtibos.
- Noto'g'ri javobga boshqa sohadan (bank, sport, oshxona) so'z yozish — taqiqlangan. Mavzu matnidagi boshqa tushunchani oling.
- Variant "xolos" yoki "shu" bilan tugasa — shablon so'z. Gapni to'liq yozing.
- Ikki savolda bir xil variant — takror. Har bir savol uchun o'z variantlari.
- Iqtibos matnda aynan bo'lishi kerak: nuqta, vergul va bo'shliqlar matndagi kabi, [1] kabi belgilarsiz.
- Matndan ko'chirilgan uzun gap noto'g'ri javob sifatida ishlatilmaydi, agar u savolga javob bermasa yoki boshqa savolning to'g'ri javobi bo'lsa. Noto'g'ri javob savol shakliga mos qisqa bo'lak bo'lsin (masalan, "...ni", "...ga" shaklida), to'g'ri javob uzunligiga yaqin bo'lsin.
- Noto'g'ri javobda meta so'zlar yo'q: `yo'riqnoma`, `qayd etilgan`, `tekshirilgan`, `tasdiqlanmagan`. Bular variantda emas, izohda ham emas.
- Mantiqiy tekshiruv (2a-band) builder da to'liq avtomatlashmagan: uzun variantli savollarni qo'lda o'qing va har variant savolga javob bo'la olishini tasdiqlang.

## Indeks bo'yicha tuzatish

Node skripti bilan JSON ni yuklang, `d['NNN'][indeks]` ni o'zgartiring, `JSON.stringify(d,null,2)` bilan saqlang va `build_tests.js --check` ni qayta ishga tushiring. Indeks 0 dan boshlanadi; QA dagi `S7` = indeks 6.
