# topic-test-xlsx — o'zgartirishlar jurnali

## 2026-11-08 — Universal qayta yozish
- Skill loyiha yo'llaridan ajratildi: skriptlar endi `scripts\` ichida, barcha yo'llar parametr orqali (`--src`, `--out`, `--questions`, `--shablon`).
- `build_tests.js` va `extract_txt.js` `scripts\` papkasiga ko'chirildi; `extract_txt.js` `unzip` o'rniga jszip ishlatadi (Windows'da unzip shart emas).
- Seans boshida 4 ta savol qo'shildi: manba, natija papkasi, soha/rol, kutubxona papkasi (ixtiyoriy). `session.json` `_build` ichida saqlanadi.
- Shablon.xlsx avtomatik qidiriladi (manba papkasi va uning ota papkasi); topilmasa so'raladi.
- Tekshiruv: `2-тоифа-янги` loyihasining 147 ta NNN.docx fayli ajratildi (147 txt), savollar JSON dan 147 ta xlsx qurildi (1483 savol, QA xatosi 0). Natija vaqtinchalik papkada, loyiha `Тест` papkasiga tegilmadi.

## 2026-11-08 — 2-тоифа: 151 mavzu uchun test to'plami
- Manba: `Эпидемиология шифокор ёрдамчиси\2-тоифа\Мавзу` (151 ta NNN.docx). Natija: `...\2-тоифа\Тест` (151 ta NNN.xlsx). Rol: Epidemiologiya bo'yicha oliy toifali shifokor. Kutubxona: `D:\KUTUBXONA`.
- Savollar: 1512 ta (har mavzuda 10–11). Partiyalar `_build\questions\NNN-MMM.json` (5 mavzudan), 001–151 barchasi qamrab olingan.
- Savol manbasi (`s`): "Mavzu materiali (shu nomdagi .docx)" yoki matndagi darslik/buyruq nomi. Matnda `[tasdiqlanmagan]` belgisi bor faktlar savol to'g'ri javobiga imkon qadar qo'yilmadi (to'liq avtomatik tekshiruv o'tkazilmagan).
- QA: xato 0; ogohlantirish (to'g'ri javob >10% uzun) 68 ta (4,5%). Harflar: A 303, B 302, C 303, D 302, E 302. Tekshiruv: jszip bilan qayta o'qildi (uch marta ketma-ket bir xil harf yo'q, kirill aralashmasi yo'q).
- Tuzatishlar (QA orqali): "Faqat/Hech/Umuman/Barcha" bilan boshlanuvchi noto'g'ri javoblar ikkitadan oshmasin; bir xil so'z bilan boshlanuvchi noto'g'ri javoblar uchtadan oshmasin. Tuzatishlar tanlangan javoblarni indeks bo'yicha Edit orqali o'zgartirish bilan bajarildi.
- Hisobot: `2-тоифа\Hisobot.md` (manbalar farqlari 18 ta band, tasdiqlanmagan belgisi bor 112 mavzu, belgilar jami 457).
- Tekshirilmagan: matnlardagi raqamli dozalar, emlash sxemalari, buyruq sanalari va tijorat manbalari; ularga oid savollar kiritilmadi yoki manba sifatida "tasdiqlanmagan" deb qayd etildi. Dezinfeksiya va sterilizatsiya rejimlari faqat matnda ko'rsatilgan darajada.

## 2026-11-08 — 2-bosqich: qat'iy sifat qoidalari va savollarni qayta yozish

- Foydalanuvchi to'qqizta majburiy qoidani kiritdi: shablon so'zlar va takror variantlar yo'q; savol va variantlar mavzuga tegishli; javob to'liq gap; savol va variantlar faqat mavzu matnidan; izoh faqat matndan iqtibos; kitob/manba nomi aytilmaydi; savol mavzuni mustahkamlaydi; hech narsa o'ylab topilmaydi; skill va fayllar yangilanadi; qoidalar qat'iy tekshiriladi.
- `scripts\build_tests.js` qat'iy rejimga o'tkazildi: QA xato bo'lsa hech bir `.xlsx` yozilmaydi. Tekshiruvlar: taqiqlangan so'zlar, shablon so'zlar, variant so'zlarining mavzu matnida bo'lishi (≥70%), tugallanmagan variantlar, iqtibos mavjudligi va uzunligi, takror variantlar (≥3 savolda), boshlang'ich so'zning takrori.
- `test-question-writing/SKILL.md` yangilandi: savolga aloqasiz variant taqiqlandi (2a-band).
- Eski 1-bosqich savollari `_build\questions_v1\` ga ko'chirildi. Yangi savollar `_build\questions\` da, mavzu bo'yicha fayllarda (001–020 tugallangan).
- Izohda manba nomi va "[tasdiqlanmagan]" belgisi chiqmaydi; izoh faqat "To'g'ri javob: ... Mavzu matnidan iqtibos: «...»" ko'rinishida.

## 2026-11-08 — 2-тоифа: yakuniy qayta tekshiruv va relevance tuzatishlari (151 mavzu)

- Natija: 151 ta `.xlsx` `2-тоифа\Тест` papkasida, savollar 1515 (har mavzuda 10–11). QA xato: 0. jszip tekshiruvi: 0 muammo.
- Harflar: A 304, B 302, C 303, D 302, E 304. Ogohlantirish (to'g'ri javob >10% uzun): 66 ta (4,4%); 30% dan oshgani yo'q.
- Mantiqiy tekshiruv: 69 ta mavzuda matndan ko'chirilgan, savolga javob bo'lmagan uzun noto'g'ri javoblar aniqlandi. Tuzatilgan mavzular: 026, 075, 076, 012, 020, 048, 071, 014, 027, 088, 011, 018, 025, 079, 101, 121, 007, 095 hamda avval 51 ta mavzu. Har almashtirish matnga (`_build\txt\NNN.txt`) asoslandi.
- Yangi QA qoidalari sinovda chiqdi va rioya qilindi: "faqat/hech/umuman/barcha" boshlanuvchi variantlar cheklandi; "qayd etilgan", "yo'riqnoma", "tez", "shu" kabi shablon/meta so'zlar noto'g'ri javoblarda taqiqlandi; trailing funksiya so'zlari (bilan/uchun) oxirida qolmasin; bir variant 3 ta savolda takrorlanmasin.
- Cheklov: relevance tekshiruvi faqat uzun variantli savollarga qaratildi. 1–2 uzun variantli mavzular va qisqa variantlarda mantiqiy xatolar to'liq tekshirilmagan. Bu skill qoidasi sifatida qayd etildi.
- `Hisobot.md` yangilandi (0-bo'lim: yakuniy tekshiruv).
- Tuzatish usuli: `_build\questions\*.json` faylidagi variantlar `apply_repl.js` (indeks → yangi matn xaritasi) orqali almashtirildi; boshqa savollar o'zgarmadi.

## 2026-11-09 — Izoh formati: "Mavzu matnidan iqtibos:" olib tashlandi
- Foydalanuvchi talabi: "Iqtibos keltir" deganda iqtibos oldiga hech narsa yozilmaydi; izoh (Comment) ustunida iqtibos to'g'ridan-to'g'ri turadi.
- Eski: `To'g'ri javob: <c>. Mavzu matnidan iqtibos: «...» (NNN.docx)`. Yangi: `To'g'ri javob: <c>. «...» (NNN.docx)`.
- O'zgartirildi: `scripts\build_tests.js` (izoh shabloni), `test-question-writing\SKILL.md` (izoh formati tavsifi).
- 151 ta `.xlsx` shu shablon bilan qayta qurildi; QA qoidalari o'zgarmadi.
