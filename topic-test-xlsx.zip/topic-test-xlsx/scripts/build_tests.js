/**
 * build_tests.js (universal, topic-test-xlsx)
 * Reads question files <questions>/*.json and writes one .xlsx per topic into <out>
 * (001 -> 001.xlsx), cloned from the shablon.xlsx template.
 *
 * Input format (per file):  { "001": [ { q, c, w:[4 wrong], x }, ... ], ... }
 *   q  - question text (ends with "?")
 *   c  - correct answer (exact text)
 *   w  - four wrong answers, taken from the SAME topic text
 *   x  - explanation: ONLY a direct quote from the topic text, in « » marks
 * Source text: <questions>/../txt/NNN.txt (produced by extract_txt.js).
 *
 * Letter placement (A-E) and option order are assigned here with a seeded RNG
 * (seed = topic number), so the result is reproducible.
 *
 * STRICT: if any QA error exists, nothing is written (exit 1).
 *
 * Usage:
 *   node build_tests.js --shablon <shablon.xlsx> --questions <dir> --out <dir>
 *   node build_tests.js --questions <dir> --check      (QA report only, no files written)
 */
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');

function loadJSZip() {
  try {
    return require('jszip');
  } catch (e) {
    /* fall through to the shared dependency folder */
  }
  try {
    return require(path.join(os.tmpdir(), 'topic-test-deps', 'node_modules', 'jszip'));
  } catch (e) {
    console.error('jszip topilmadi. O\'rnating: npm install --prefix "%TEMP%\\topic-test-deps" jszip');
    process.exit(3);
  }
}
const JSZip = loadJSZip();

function arg(name) {
  const i = process.argv.indexOf(name);
  return i >= 0 && i + 1 < process.argv.length ? process.argv[i + 1] : null;
}
const SHABLON = arg('--shablon');
const QDIR = arg('--questions');
const OUTDIR = arg('--out');
const CHECK_ONLY = process.argv.includes('--check');

if (!QDIR || (!CHECK_ONLY && (!OUTDIR || !SHABLON))) {
  console.error('Foydalanish: node build_tests.js --shablon <shablon.xlsx> --questions <dir> --out <dir>');
  console.error('        yoki: node build_tests.js --questions <dir> --check');
  process.exit(2);
}

const TXT_DIR = path.join(QDIR, '..', 'txt');
const LETTERS = ['A', 'B', 'C', 'D', 'E'];
const COLS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
const HEADER = ['Question', 'A', 'B', 'C', 'D', 'E', 'Correct', "Comment (Faqat to'g'ri javob uchun)"];
const MIN_Q = 10;
const ON_TOPIC_MIN = 0.7; // share of an answer's words that must occur in the topic text

// Forbidden: book/source references and meta words (rule: no "falonchi kitobida ..." phrasing).
const FORBID = /\b(darslik|kitob|taqdimot|slayd|mirtazaev|pakirdinov|valixonov|zueva|matnazarova|manbada|manbalar|deyilgan|ko'rsatilgan|qayd etilgan|tasdiqlanmagan|muallif|buyruq|buyrug'i|ocr|presentatsiya|prezentatsiya)\b|kutubxon|yo'riqnom|qo'llanma/i;
// Template filler words that must not appear in answers.
const FILLER = /\b(xolos|shu|tez|odatiy)\b/i;
// Answer must not end with a dangling connector.
const DANGLING = new Set(['va', 'yoki', 'bilan', 'uchun', 'ham', 'kabi', 'ga', 'da', 'dan', 'ni', 'ammo', 'lekin', 'esa', 'hamda']);

// ── seeded RNG (mulberry32) ──────────────────────────────────────────────────
function rng(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function shuffle(arr, rand) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Balanced letter plan: blocks of a shuffled A-E permutation.
function letterPlan(n, rand) {
  const out = [];
  while (out.length < n) out.push(...shuffle(LETTERS, rand));
  return out.slice(0, n);
}

function xmlEsc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ── text helpers ─────────────────────────────────────────────────────────────
function norm(s) {
  return String(s)
    .replace(/\[[^\]]*\]/g, ' ')
    .replace(/[’‘ʻʼ`´]/g, "'")
    .replace(/\s+/g, ' ')
    .toLowerCase()
    .trim();
}
function stem(t) { return t.slice(0, 5); }
function toks(s) {
  return (norm(s).match(/[a-z0-9'Ѐ-ӿ]{3,}/g) || [])
    .map((t) => t.replace(/^'+|'+$/g, ''))
    .filter((t) => t.length >= 3);
}
const txtCache = {};
function topicText(id) {
  if (!(id in txtCache)) {
    const p = path.join(TXT_DIR, `${id}.txt`);
    txtCache[id] = fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : null;
  }
  return txtCache[id];
}

// ── QA on source data (strict) ──────────────────────────────────────────────
function qaTopic(id, qs) {
  const issues = [];
  const warn = [];
  if (qs.length < MIN_Q) issues.push(`savollar soni ${qs.length} < ${MIN_Q}`);
  const tx = topicText(id);
  if (tx === null) issues.push(`${id}.txt topilmadi (manba matni yo'q)`);
  const txNorm = tx === null ? '' : norm(tx);
  const txSet = new Set(toks(txNorm).map(stem));
  const seenAnswers = new Map();

  qs.forEach((r, i) => {
    const n = i + 1;
    const opts = [r.c, ...r.w];
    if (!r.q || !/\?\s*$/.test(r.q)) issues.push(`S${n}: savol "?" bilan tugamagan`);
    if (new Set(opts.map((o) => norm(o))).size !== 5) issues.push(`S${n}: takroriy variant`);
    if (r.w.length !== 4) issues.push(`S${n}: noto'g'ri javoblar soni ${r.w.length} (4 bo'lishi kerak)`);

    // rule 5 / 1: no book references, no filler words
    const allText = [r.q, ...opts].join(' | ');
    const fb = allText.match(FORBID);
    if (fb) issues.push(`S${n}: taqiqlangan so'z: "${fb[0]}" (kitob/manba ko'rsatkichi yoki meta so'z)`);
    const fl = opts.join(' | ').match(FILLER);
    if (fl) issues.push(`S${n}: shablon so'z: "${fl[0]}" (variantlarda takrorlanadigan so'z ishlatilgan)`);

    // rule 2: every answer must be on the topic (words taken from the topic text)
    for (const o of opts) {
      const t = toks(o);
      if (!t.length) { issues.push(`S${n}: bo'sh variant`); continue; }
      const frac = t.filter((x) => txSet.has(stem(x))).length / t.length;
      if (tx !== null && frac < ON_TOPIC_MIN) {
        issues.push(`S${n}: variant mavzudan chetda (${Math.round(frac * 100)}%): "${o}"`);
      }
      // rule 3: complete, meaningful answer
      const words = o.trim().split(/\s+/);
      const last = words[words.length - 1].toLowerCase().replace(/[.,;:!?]+$/, '');
      if (DANGLING.has(last) || /[,;:\-–]$/.test(o.trim())) {
        issues.push(`S${n}: variant tugallanmagan yoki ma'nosiz: "${o}"`);
      }
      const k = norm(o);
      if (k.length >= 8) {
        if (!seenAnswers.has(k)) seenAnswers.set(k, new Set());
        seenAnswers.get(k).add(n);
      }
    }

    // rule 4: explanation = direct quote from the topic text supporting the correct answer
    const m = r.x && r.x.match(/[«"]([^»"]+)[»"]/);
    if (!m) {
      issues.push(`S${n}: izohda mavzu matnidan iqtibos (« ») yo'q`);
    } else {
      const qn = norm(m[1]);
      if (qn.length < 20) issues.push(`S${n}: iqtibos juda qisqa`);
      else if (tx !== null && !txNorm.includes(qn)) issues.push(`S${n}: iqtibos mavzu matnida topilmadi: "${m[1].slice(0, 60)}..."`);
      const rest = r.x.replace(m[0], '').replace(/[.\s]/g, '');
      if (rest.length) issues.push(`S${n}: izohda iqtibosdan tashqari matn bor (faqat iqtibos ruxsat)`);
      const ct = toks(r.c);
      const qt = new Set(toks(m[1]).map(stem));
      const sup = ct.length ? ct.filter((t) => qt.has(stem(t))).length / ct.length : 0;
      if (sup < 0.5) issues.push(`S${n}: iqtibos to'g'ri javobni qo'llab-quvvatlamaydi`);
    }

    // length balance (carried over)
    const maxW = Math.max(...r.w.map((w) => w.length));
    const ratio = r.c.length / maxW;
    if (ratio > 1.3) issues.push(`S${n}: to'g'ri javob ${(100 * (ratio - 1)).toFixed(0)}% uzun`);
    else if (ratio > 1.1) warn.push(`S${n}: to'g'ri javob ${(100 * (ratio - 1)).toFixed(0)}% uzun`);

    const extremes = r.w.filter((w) => /^(Faqat|Hech|Umuman|Barcha)\b/i.test(w));
    if (extremes.length > 1) issues.push(`S${n}: ${extremes.length} ta "Faqat/Hech/Umuman/Barcha" noto'g'ri javob`);
    const fw = {};
    for (const w of r.w) {
      const k = w.split(/\s/)[0].toLowerCase();
      fw[k] = (fw[k] || 0) + 1;
    }
    const cfw = r.c.split(/\s/)[0].toLowerCase();
    for (const [k, v] of Object.entries(fw)) {
      if (v >= 3 && k !== cfw) issues.push(`S${n}: ${v} ta noto'g'ri javob "${k}" bilan boshlanadi`);
    }
  });

  // rule 1: the same answer text must not be reused across questions of one topic
  for (const [k, set] of seenAnswers) {
    if (set.size >= 3) issues.push(`takrorlangan variant (S${[...set].join(',S')}): "${k.slice(0, 60)}"`);
  }
  return { issues, warn };
}

function buildRows(qs, topicId) {
  const num = parseInt(topicId, 10);
  const plan = letterPlan(qs.length, rng(num * 7919 + 17));
  return qs.map((r, i) => {
    const letter = plan[i];
    const wrongs = shuffle(r.w, rng(num * 104729 + i * 31 + 5));
    const opts = {};
    let wi = 0;
    for (const L of LETTERS) opts[L] = L === letter ? r.c : wrongs[wi++];
    const x = r.x.endsWith('.') ? r.x : r.x + '.';
    const comment = `To'g'ri javob: ${r.c}. ${x} (${topicId}.docx)`;
    return { q: r.q, ...opts, correct: letter, comment };
  });
}

// ── sheet + shared strings ──────────────────────────────────────────────────
function buildSheetAndStrings(rows, templateSheet) {
  const all = [...HEADER];
  for (const r of rows) all.push(r.q, r.A, r.B, r.C, r.D, r.E, r.correct, r.comment);
  const unique = [];
  const idx = new Map();
  for (const s of all) {
    if (!idx.has(s)) {
      idx.set(s, unique.length);
      unique.push(s);
    }
  }
  const si = unique.map((s) => `<si><t xml:space="preserve">${xmlEsc(s)}</t></si>`).join('');
  const sst = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${all.length}" uniqueCount="${unique.length}">${si}</sst>`;

  const cellS = (ref, value, style) => `<c r="${ref}" s="${style}" t="s"><v>${idx.get(value)}</v></c>`;
  // Estimated row heights so wrapped text stays visible (column widths come from the template).
  const widths = [21.77734375, 15.6640625, 16, 14.33203125, 16.21875, 14.33203125, 7.109375, 84.44140625];
  const lineH = 14.4;
  const estH = (vals) => {
    let lines = 1;
    vals.forEach((v, c) => {
      const cpl = Math.max(1, Math.floor(widths[c] * 1.15));
      lines = Math.max(lines, Math.ceil(String(v).length / cpl));
    });
    return (lines * lineH + 2).toFixed(1);
  };

  let sheetData = `<row r="1" spans="1:8" s="3" customFormat="1" x14ac:dyDescent="0.3">`;
  HEADER.forEach((h, c) => (sheetData += cellS(`${COLS[c]}1`, h, 2)));
  sheetData += `</row>`;

  rows.forEach((r, i) => {
    const rn = i + 2;
    const vals = [r.q, r.A, r.B, r.C, r.D, r.E, r.correct, r.comment];
    sheetData += `<row r="${rn}" spans="1:8" ht="${estH(vals)}" customHeight="1" x14ac:dyDescent="0.3">`;
    vals.forEach((v, c) => (sheetData += cellS(`${COLS[c]}${rn}`, v, c === 6 ? 3 : 1)));
    sheetData += `</row>`;
  });

  const lastRow = rows.length + 1;
  const sheet = templateSheet
    .replace(/<dimension ref="[^"]*"\/>/, `<dimension ref="A1:H${lastRow}"/>`)
    .replace(/<sheetData>[\s\S]*<\/sheetData>/, `<sheetData>${sheetData}</sheetData>`);
  return { sst, sheet };
}

// ── main ────────────────────────────────────────────────────────────────────
async function main() {
  const files = fs.readdirSync(QDIR).filter((f) => f.endsWith('.json')).sort();
  const byTopic = {};
  for (const f of files) {
    const data = JSON.parse(fs.readFileSync(path.join(QDIR, f), 'utf8').replace(/^﻿/, ''));
    for (const [id, qs] of Object.entries(data)) {
      if (byTopic[id]) throw new Error(`Topic ${id} defined twice (${f})`);
      byTopic[id] = qs;
    }
  }
  const ids = Object.keys(byTopic).sort();
  if (!ids.length) {
    console.error('No topics found in', QDIR);
    process.exit(1);
  }

  // QA first: strict mode refuses to write anything while errors remain.
  const report = [];
  let warnCount = 0;
  for (const id of ids) {
    const { issues, warn } = qaTopic(id, byTopic[id]);
    if (issues.length || warn.length) report.push({ id, issues, warn });
    warnCount += warn.length;
  }
  const bad = report.filter((r) => r.issues.length);

  const dist = { A: 0, B: 0, C: 0, D: 0, E: 0 };
  let totalQ = 0;
  let longCount = 0;
  const builtRows = {};
  for (const id of ids) {
    const rows = buildRows(byTopic[id], id);
    builtRows[id] = rows;
    for (const r of rows) {
      dist[r.correct]++;
      const c = r[r.correct];
      const maxW = Math.max(...LETTERS.filter((L) => L !== r.correct).map((L) => r[L].length));
      if (c.length > maxW * 1.1) longCount++;
    }
    totalQ += rows.length;
  }

  if (bad.length) {
    console.log(`QA xatolari: ${bad.length} fayl. Fayllar YOZILMADI (qat'iy rejim).`);
    for (const r of bad) {
      for (const i of r.issues) console.log(`  [${r.id}] ${i}`);
    }
    process.exit(1);
  }

  if (!CHECK_ONLY) {
    if (!fs.existsSync(SHABLON)) {
      console.error('Shablon topilmadi:', SHABLON);
      process.exit(1);
    }
    const tpl = await JSZip.loadAsync(fs.readFileSync(SHABLON));
    const templateSheet = await tpl.file('xl/worksheets/sheet1.xml').async('string');
    if (!fs.existsSync(OUTDIR)) fs.mkdirSync(OUTDIR, { recursive: true });
    const skipped = [];
    for (const id of ids) {
      const zip = new JSZip();
      for (const name of Object.keys(tpl.files)) {
        if (!tpl.files[name].dir && name !== 'xl/sharedStrings.xml' && name !== 'xl/worksheets/sheet1.xml') {
          zip.file(name, await tpl.file(name).async('nodebuffer'));
        }
      }
      const { sst, sheet } = buildSheetAndStrings(builtRows[id], templateSheet);
      zip.file('xl/sharedStrings.xml', sst);
      zip.file('xl/worksheets/sheet1.xml', sheet);
      const buf = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 6 } });
      try {
        fs.writeFileSync(path.join(OUTDIR, `${id}.xlsx`), buf);
      } catch (e) {
        if (e.code !== 'EBUSY' && e.code !== 'EPERM') throw e;
        skipped.push(id);
      }
    }
    if (skipped.length) console.log(`Yozilmadi (fayl ochiq/band): ${skipped.join(', ')}`);
    console.log(`Natija papkasi: ${OUTDIR}`);
  }

  console.log('══════════════════════════════════════════════════════');
  console.log(`Fayllar soni   : ${ids.length}`);
  console.log(`Savollar soni  : ${totalQ}`);
  console.log(`To'g'ri javob taqsimoti: A=${dist.A} B=${dist.B} C=${dist.C} D=${dist.D} E=${dist.E}`);
  console.log(`To'g'ri javob >10% uzun: ${longCount} ta (${((100 * longCount) / totalQ).toFixed(1)}%)`);
  console.log(`Ogohlantirishlar (>10%): ${warnCount}`);
  console.log('QA xatolari: 0 fayl');
  for (const r of report) for (const w of r.warn) console.log(`  [${r.id}] (ogohlantirish) ${w}`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
