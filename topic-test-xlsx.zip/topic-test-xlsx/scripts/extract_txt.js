/**
 * extract_txt.js (universal, topic-test-xlsx)
 * Extracts plain text from every NNN.docx in <src> into <out>/NNN.txt.
 *
 * Usage: node extract_txt.js --src <dir with NNN.docx> --out <dir for NNN.txt>
 * Uses JSZip (no external "unzip" tool needed).
 */
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');

function loadJSZip() {
  try {
    return require('jszip');
  } catch (e) {
    /* fall through */
  }
  try {
    return require(path.join(os.tmpdir(), 'topic-test-deps', 'node_modules', 'jszip'));
  } catch (e) {
    console.error('jszip topilmadi. O\'rnating: npm install --prefix "%TEMP%\\topic-test-deps" jszip');
    process.exit(3);
  }
}
const JSZip = loadJSZip();

function arg(name) {
  const i = process.argv.indexOf(name);
  return i >= 0 && i + 1 < process.argv.length ? process.argv[i + 1] : null;
}
const SRC = arg('--src');
const OUT = arg('--out');
if (!SRC || !OUT) {
  console.error('Foydalanish: node extract_txt.js --src <dir with NNN.docx> --out <dir for NNN.txt>');
  process.exit(2);
}

const ents = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
function unent(s) {
  return s
    .replace(/&(amp|lt|gt|quot|apos);/g, (m, k) => ents[k])
    .replace(/&#(\d+);/g, (m, d) => String.fromCodePoint(+d))
    .replace(/&#x([0-9a-fA-F]+);/g, (m, h) => String.fromCodePoint(parseInt(h, 16)));
}

async function docxText(file) {
  const zip = await JSZip.loadAsync(fs.readFileSync(file));
  const entry = zip.file('word/document.xml');
  if (!entry) throw new Error(`word/document.xml yo'q: ${file}`);
  const xml = await entry.async('string');
  const body = xml.replace(/<w:instrText[\s\S]*?<\/w:instrText>/g, '');
  const paras = body.split(/<w:p[ >]/).slice(1);
  const lines = [];
  for (const p of paras) {
    const t = p.replace(/<w:tab\/>/g, '\t').replace(/<w:br\/>/g, '\n');
    const runs = [...t.matchAll(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g)].map((m) => unent(m[1]));
    lines.push(runs.join('').replace(/\s+/g, ' ').trim());
  }
  const out = [];
  let blank = false;
  for (const l of lines) {
    if (!l) {
      if (!blank) out.push('');
      blank = true;
    } else {
      out.push(l);
      blank = false;
    }
  }
  return out.join('\n').trim() + '\n';
}

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const files = fs.readdirSync(SRC).filter((f) => /^\d+\.docx$/i.test(f)).sort();
  if (!files.length) {
    console.error('NNN.docx fayllar topilmadi:', SRC);
    process.exit(1);
  }
  let total = 0;
  for (const f of files) {
    const txt = await docxText(path.join(SRC, f));
    fs.writeFileSync(path.join(OUT, f.replace(/\.docx$/i, '.txt')), txt, 'utf8');
    total += txt.length;
  }
  console.log('files:', files.length, 'totalChars:', total);
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
