---
name: topic-test-xlsx
description: Mavzu .docx fayllaridan (001.docx...NNN.docx) shablon.xlsx formatida test .xlsx fayllarini ommaviy yaratish bo'yicha to'liq ish tartibi. Istalgan soha uchun universal (tibbiyot, biologiya, huquq va h.k.). "test tuz", "docx dan xlsx test", "shablon.xlsx", "mavzu testlari" so'rovlarida ishlatiladi.
---

# Mavzu .docx → test .xlsx (universal)

Har bir mavzu uchun alohida `.xlsx` test yaratiladi (`001.docx` → `001.xlsx`). Har faylda 10–11 savol, `shablon.xlsx` formatida (ustunlar: Question | A | B | C | D | E | Correct | Comment).

Savollar, variantlar va izohlar **faqat mavzu matnidan** olinadi. Har bir izoh mavzu matnidan to'g'ridan-to'g'ri iqtibos bo'ladi. Kitob yoki manba nomi savolda ham, variantda ham, izohda ham aytilmaydi.

Skill fayllari: `C:\Users\xkomilov\.claude\skills\topic-test-xlsx\`
- `scripts\extract_txt.js` — NNN.docx → NNN.txt (matn ajratish)
- `scripts\build_tests.js` — savollar JSON → NNN.xlsx, qat'iy QA (xato bo'lsa hech narsa yozmaydi)
- `references\changelog.md` — seans o'zgartirishlari jurnali
- Bog'liq skill: `test-question-writing` (savol yozish qat'iy qoidalari; majburiy o'qilsin), `docx-xlsx-node-pipeline` (docx/xlsx texnikasi)

## 0. Seans boshida (majburiy — avval so'raladi)

Ishni boshlashdan oldin foydalanuvchidan bitta xabarda so'rang:

1. **Manba** — mavzular `.docx` fayllari (`NNN.docx`) saqlangan papka yo'li (majburiy).
2. **Natija papkasi** — tayyor `NNN.xlsx` fayllar yoziladigan papka (majburiy).
3. **Soha / rol** — masalan "epidemiolog, virusolog, immunolog, parazitolog". Berilmasa, manba faylning boshidagi rol tavsifidan olinadi.
4. **Qo'shimcha ma'lumot papkasi** (ixtiyoriy) — kutubxona materiallari (masalan `D:\KUTUBXONA`). Berilmasa faqat internet manbalari ishlatiladi. Savol va izohlar baribir faqat mavzu matnidan olinadi.

Javoblarni `<manba-papkasi>\_build\session.json` ga yozing:
`{"source": "...", "output": "...", "role": "...", "library": "..."}`.
Foydalanuvchi bergan yo'llarni o'zgartirmasdan ishlating; bo'sh joy yoki kirill harflar bo'lsa, yo'lni qo'shtirnoq ichida ishlating.

**Shablon.xlsx** alohida so'ralmaydi: avval `<manba-papkasi>\shablon.xlsx`, keyin `<manba-papkasi>\..\shablon.xlsx` ni qidiring. Topilmasa, faqat shu holatda foydalanuvchidan yo'lini so'rang.

Ish papkasi: `<manba-papkasi>\_build\` (ichida `questions\`, `txt\`, `session.json`). Natija papkasi faqat `.xlsx` fayllar uchun.

## 1. Bir martalik sozlash

```bash
npm install --prefix "%TEMP%\topic-test-deps" jszip
```

Skriptlar `jszip` ni avval joriy papkadan, keyin `%TEMP%\topic-test-deps` dan izlaydi; loyihaga qo'shilmaydi.

## 2. Matnni ajratish

```bash
node "C:\Users\xkomilov\.claude\skills\topic-test-xlsx\scripts\extract_txt.js" --src "<manba-papkasi>" --out "<manba-papkasi>\_build\txt"
```

Natija: har bir `NNN.docx` uchun `_build\txt\NNN.txt`. Savol yozishdan oldin har bir mavzu matnini o'qing; `build_tests.js` iqtiboslarni shu fayldan tekshiradi.

## 3. Partiyalab savol yozish

- 5 ta mavzuni o'qing, har biri uchun 10–11 savol yozing va `_build\questions\NNN-MMM.json` ga saqlang.
- Qoidalar: `test-question-writing` skill (majburiy). Asosiy qoidalar: shablon so'z yo'q; har bir variant mavzu matnidan; ma'no to'liq; izoh faqat « » ichidagi iqtibos; kitob/manba nomi yo'q; takror variant yo'q.
- Bir faylda faqat bitta partiya; bir mavzu ikki faylda takrorlanmasin.
- JSON formati: `{ "001": [ { "q": "... ?", "c": "to'g'ri javob", "w": ["x1","x2","x3","x4"], "x": "«mavzu matnidan aynan iqtibos»" } ] }`. `s` maydoni kerak emas.

## 4. Qurish va QA (qat'iy)

```bash
node "C:\Users\xkomilov\.claude\skills\topic-test-xlsx\scripts\build_tests.js" --shablon "<shablon.xlsx>" --questions "<manba-papkasi>\_build\questions" --out "<natija-papkasi>"
```

Faqat tekshirish (fayl yozmasdan):

```bash
node "C:\Users\xkomilov\.claude\skills\topic-test-xlsx\scripts\build_tests.js" --questions "<manba-papkasi>\_build\questions" --check
```

Qat'iy rejim: birorta QA xato bo'lsa, skript hech bir `.xlsx` yozmaydi va xatolar ro'yxatini chiqaradi. Xatolar 0 bo'lgunga qadar tuzating. Tuzatish indeks bo'yicha (JSON ni `node` bilan yuklab, bitta savolni almashtirib qayta saqlash) bajariladi; butun faylni qayta yozmang.

Tekshiriladigan qoidalar: savol `?` bilan tugaydi; taqiqlangan so'zlar (kitob/muallif/`deyilgan`/`ko'rsatilgan` va h.k.) yo'q; shablon so'zlar (`xolos`, `shu`, `tez`, `odatiy`) yo'q; variant so'zlarining ≥70% i `NNN.txt` da bor; variant tugallangan; izoh faqat « » ichidagi iqtibos, u `NNN.txt` da aynan bor va to'g'ri javobni qo'llab-quvvatlaydi; takror variantlar yo'q; to'g'ri javob >30% uzun emas.

## 5. Yakuniy tekshiruv

Barcha `.xlsx` ni jszip bilan qayta o'qing: savollar soni 10–11, harflar taqsimoti, uch marta ketma-ket bir xil harf yo'qligi, izohda iqtibos bor, kirill aralashmasi yo'qligi.

## 6. Hisobot (o'zbekcha, `<manba-papkasi>\..\Hisobot.md`)

1. Fayllar va savollar soni.
2. A/B/C/D/E taqsimoti.
3. To'g'ri javob 10% dan uzun bo'lgan savollar ulushi.
4. Mavzu matnlari o'rtasidagi farqlar (manbalar ziddiyati) — qo'lda tuzilgan raqamli ro'yxat, har bir band mavzu raqami bilan.
5. Matndagi `[tasdiqlanmagan]` belgili faktlar — mavzu bo'yicha ro'yxat.

## 7. Seans o'zgartirishlari

Foydalanuvchi kiritgan **har bir** o'zgartirishni (savol uslubi, format, papka, qoida) darhol `references\changelog.md` ga sana bilan yozing. Agar o'zgartirish skript yoki SKILL.md ga ta'sir qilsa, ularni ham yangilang.

## Eslatmalar

- Fayl Excel'da ochiq bo'lsa yozish `EBUSY` beradi; skript bunday faylni o'tkazib yuboradi va "Yozilmadi" deb xabar beradi. Excel yopilgach qayta ishga tushiring. `~$NNN.xlsx` — Excel qulf fayli, tegilmaydi.
- Aralashtirish `mulberry32` + mavzu raqami seed'i bilan deterministik: qayta qurilganda natija o'zgarmaydi.
- Tekshiruv faqat jszip orqali qayta o'qishga tayanadi; bitta faylni Excel'da ochib ko'rishni tavsiya qiling.
- Tibbiy mazmun (dozalar, me'yorlar) mutaxassis tomonidan tekshirilishi kerak; skript faqat matn mosligini tekshiradi.
